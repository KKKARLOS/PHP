<?php
	include("../modelos/clase_partida.php");

	$partida = new CPartida();
	
	switch ($_POST["funcion"]) {

		case "Comenzar":
			
			$partida->Comenzar();
			break;

		case "ObtenerPremio":

			$partida->ObtenerPremio($partida->valores);
			break;		
	}
	echo json_encode($partida);
?>