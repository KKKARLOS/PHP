<?php
	function obtenerTipoUsuario($id) {
		global $conn;

		$sql = "SELECT tipo_usuario FROM usuarios WHERE usuario_id = '$id'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {

			while($row = $result->fetch_assoc()) {
				$respuesta = $row["tipo_usuario"];
			}
		} else {
			$respuesta = 0;
		}

		$conn->close();

		return $respuesta;
	}

	function obtenerTodosPartidos() {
		global $conn;

		$sql = "SELECT * FROM partidos ORDER BY fecha_inicio";
		$result = $conn->query($sql);

		return $result;
	}

	function formatearFecha($fecha) {
		$date = date_create($fecha);

		$respuesta = date_format($date, 'Y') . "-";
		$respuesta = $respuesta . "" . date_format($date, 'm') . "-";
		$respuesta = $respuesta . "" . date_format($date, 'j') . "T";
		$respuesta = $respuesta . "" . date_format($date, 'H') . ":";
		$respuesta = $respuesta . "" . date_format($date, 'i');

		return $respuesta;
	}

	function obtenersaldousuario($usuario_id){
		global $conn;

		$sql = "SELECT saldo FROM usuarios WHERE usuario_id=$usuario_id";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {

			while($row = $result->fetch_assoc()) {
				$respuesta = $row["saldo"];
			}
		} else {
			$respuesta = 0;
		}

		$conn->close();

		return $respuesta;
	}

	function mostrarpartidosapostados($usuario_id){
		global $conn;

		$parti = "SELECT partido_id FROM apuestas WHERE usuario_id=$usuario_id";
		$resultado = mysqli_query($conn, $parti);

		$respuesta[] = null;

		if (mysqli_num_rows($resultado) > 0) {
	  		             
	    	while($row = mysqli_fetch_assoc($resultado)) {
	    		$partido_id=$row['partido_id'];
	    		$respuesta[]=$partido_id;
	       		}
		  	}

			return $respuesta;  
	}
?>