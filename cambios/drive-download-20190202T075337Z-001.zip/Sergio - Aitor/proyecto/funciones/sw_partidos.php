<?php
	include("../conexion.php");

	switch ($_POST["accion"]) {

		case "Insert":
			$partido = $_POST["partido"];
			$fecha_inicio = $_POST["fecha_inicio"];
			$min_gol = $_POST["min_gol"];
			$finalizado = $_POST["finalizado"];
			$anulado = $_POST["anulado"];

			if($min_gol == -1) {
				$min_gol = "NULL";
			}

			$sql = "INSERT INTO partidos (partido, fecha_inicio, min_gol, finalizado, anulado) VALUES ('$partido', '$fecha_inicio', $min_gol, '$finalizado', '$anulado')";

			if ($conn->query($sql) === TRUE) {
				$partido_id = $conn->insert_id;

				$sql = "SELECT * FROM partidos WHERE partido_id = '$partido_id'";
				$result = $conn->query($sql);

				while($row = $result->fetch_assoc()) {
					$filas[] = $row;
				}

				$respuesta = json_encode($filas);
			} else {
				$respuesta = 0;
			}

			$conn->close();

			break;

		case "Update":
			$id = $_POST["id"];
			$partido = $_POST["partido"];
			$fecha_inicio = $_POST["fecha_inicio"];
			$min_gol = $_POST["min_gol"];
			$finalizado = $_POST["finalizado"];
			$anulado = $_POST["anulado"];

			if($min_gol == -1) {
				$min_gol = "NULL";
			}

			if($finalizado == 1) {
				$sqlSelectApuestas = "SELECT * FROM apuestas WHERE partido_id = '$id' AND min_gol < '$min_gol'";
				$result = $conn->query($sqlSelectApuestas);

				while($row = $result->fetch_assoc()) {
					$usuarioId = $row["usuario_id"];
					$apuesta = $row["apuesta"];
					$min_gol_usuario = $row["min_gol"];

					// 20min apostado * 30€ apostado
					// ----------------------------
					//              10

					$ganancias = ($min_gol_usuario * $apuesta) / 10;

					$sqlUpdateUsuarios = "UPDATE usuarios SET saldo=saldo+$ganancias WHERE usuario_id = '$usuarioId'";
					$conn->query($sqlUpdateUsuarios);
				}
			}

			if($anulado == 1) {
				$sqlSelectApuestas = "SELECT * FROM apuestas WHERE partido_id = '$id'";
				$result = $conn->query($sqlSelectApuestas);

				while($row = $result->fetch_assoc()) {
					$usuarioId = $row["usuario_id"];
					$apuesta = $row["apuesta"];

					$sqlUpdateUsuarios = "UPDATE usuarios SET saldo=saldo+$apuesta WHERE usuario_id = '$usuarioId'";
					$conn->query($sqlUpdateUsuarios);
				}
			}

			$sql = "UPDATE partidos SET partido='$partido', fecha_inicio='$fecha_inicio', min_gol=$min_gol, finalizado='$finalizado', anulado='$anulado' WHERE partido_id='$id'";

			if ($conn->query($sql) === TRUE) {
				$respuesta = 1;
			} else {
				$respuesta = 0;
			}

			$conn->close();

			break;

		case "Delete":
			$id = $_POST["id"];

			$sqlSelect = "SELECT * FROM apuestas WHERE partido_id = '$id'";
			$result = $conn->query($sqlSelect);

			if ($result->num_rows > 0) {

				$respuesta = -1;

			} else {
				$sqlDelete = "DELETE FROM partidos WHERE partido_id='$id'";

				if ($conn->query($sqlDelete) === TRUE) {
					$respuesta = 1;
				} else {
					$respuesta = 0;
				}
			}

			$conn->close();

			break;
	}

	echo $respuesta;
?>