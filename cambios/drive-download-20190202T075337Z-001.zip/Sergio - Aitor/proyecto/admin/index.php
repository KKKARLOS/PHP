<?php
	session_start();

	include("../conexion.php");
	include("../funciones/funciones.php");
?>

<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>BEFORE GOAL - admin</title>
		<link rel="stylesheet" type="text/css" href="../css/estilos.css">
		<script src="../jquery.min.js"></script>
	</head>
	<body>
		<?php if(isset($_SESSION["usuarioID"])) { ?>

			<!-- MENU SUPERIOR -->
			<div class="menu">
				<a href="."><img src="../img/beforegoal_alt.png" width="14px" height="14px"> <b>BEFORE GOAL</b></a>
				<a style="float: right;" href="../logout.php">LOGOUT</a>
			</div>
			
			<!-- CONTENIDO PÁGINA ADMINNISTRADOR -->
			<div class="contenido">

				<table width='100%' cellpadding='8' cellspacing='0' id="partidos" class="tablaPartidos">
					<tr>
						<th>PARTIDO</th><th>FECHA</th><th>GOL</th><th>FINALIZADO</th><th>ANULADO</th><th></th>
					</tr>

					<tr>
						<form id='form_partido_nuevo'>
							<td>
								<input type='text' id='partido_nuevo' name='partido_nuevo' placeholder='Partido'>
							</td>
							<td>
								<input type='datetime-local' id='fecha_inicio_nuevo'>
							</td>
							<td>
								<input type='number' id='min_gol_nuevo' placeholder='Minuto Gol' min="0" max="90" step='0'>
							</td>
							<td>
								<input type='checkbox' id='finalizado_nuevo' value='1'>
							</td>
							<td>
								<input type='checkbox' id='anulado_nuevo' value='1'>
							</td>
							<td>
								<input type='button' value='Añadir' class='buttonAlt' onclick='insertarPartido()' />
							</td>
						</form>
					</tr>
<?php
					$todosPartidos = obtenerTodosPartidos();
					if ($todosPartidos->num_rows > 0) {
						while($row = $todosPartidos->fetch_assoc()) {
							$id = $row["partido_id"];
							$partido = $row["partido"];
							$fecha_inicio = $row["fecha_inicio"];
							$min_gol = $row["min_gol"];
							$finalizado = $row["finalizado"];
							$anulado = $row["anulado"];

							$partidoActivo = "";
							if($finalizado == 1 || $anulado == 1) {
								$partidoActivo = "disabled";
							}

							echo "<tr>";
								echo "<td>";
										echo "<input type='text' id='partido_" . $id . "'  placeholder='Partido' value='" . $partido . "' readonly $partidoActivo>";
								echo "</td>";
								echo "<td>";
										echo "<input type='datetime-local' id='fecha_inicio_" . $id . "' value='" . formatearFecha($fecha_inicio) . "' readonly $partidoActivo>";
								echo "</td>";
								echo "<td>";
										echo "<input type='number' id='min_gol_" . $id . "' placeholder='Minuto Gol' value='" . $min_gol . "' min='0' max='90' step='0' $partidoActivo>";
								echo "</td>";
								echo "<td>";
									if($finalizado == 1) {
										echo "<input type='checkbox' id='finalizado_" . $id . "' value='1' checked $partidoActivo>";
									} else {
										echo "<input type='checkbox' id='finalizado_" . $id . "' value='1' $partidoActivo>";
									}
								echo "</td>";
								echo "<td>";
									if($anulado == 1) {
										echo "<input type='checkbox' id='anulado_" . $id . "' value='1' checked $partidoActivo>";
									} else {
										echo "<input type='checkbox' id='anulado_" . $id . "' value='1' $partidoActivo>";
									}
								echo "</td>";
								echo "<td>" .
									"<input type='button' value='Actualizar' onclick='actualizarPartido(" . $id . ")' class='button' $partidoActivo /> " .
									"<input type='button' value='Eliminar' onclick='eliminarPartido(" . $id . ")' class='button' $partidoActivo />" .
									"</td>";
							echo "</tr>";
						}
					}
?>
				</table>
			</div>

			<script type="text/javascript">
				function insertarPartido() {

					if($("#min_gol_nuevo").val() == "") {
						$min_gol = -1;
					} else {
						$min_gol = $("#min_gol_nuevo").val();
					}

					$fin= 0;
					if($("#finalizado_nuevo").prop('checked') ) {
						$fin = 1;
					}

					$anu = 0;
					if($("#anulado_nuevo").prop('checked') ) {
						$anu = 1;
					}

					if($("#partido_nuevo").val() == "") {

						alert("Rellena el campo partido");

					} else if($("#fecha_inicio_nuevo").val() == "") {

						alert("Rellena el campo fecha y hora");

					} else if($fin == 1 && $min_gol == -1) {

						alert("Rellena el campo minuto gol");

					} {

						var parametros = {
							accion : "Insert",
							partido: $("#partido_nuevo").val(),
							fecha_inicio: $("#fecha_inicio_nuevo").val(),
							min_gol: $min_gol,
							finalizado: $fin,
							anulado: $anu
						};

						$.ajax({
							type: 'POST',
							url: "../funciones/sw_partidos.php",
							data: parametros,
							success: function(data){
								console.log(data);
								if (data != 0) {
									location.reload();
									alert("Partido insertado correctamente");									
								} else {
									alert("ERROR: Partido nuevo no insertado");								
								}
							},
							error: function (xhr, status, error) {
								console.log("ERROR: " + err.Message);
							}
						});
					}



					Number.prototype.AddZero= function(b, c){
						var  l = (String(b || 10).length - String(this).length) + 1;

						return l > 0 ? new Array(l).join(c || '0') + this : this;
					}
				}

				function actualizarPartido($id) {

					if($("#min_gol_" + $id).val() == "") {
						$min_gol = -1;
					} else {
						$min_gol = $("#min_gol_" + $id).val();
					}

					$fin= 0;
					if($("#finalizado_" + $id).prop('checked') ) {
						$fin = 1;
					}

					$anu = 0;
					if($("#anulado_" + $id).prop('checked') ) {
						$anu = 1;
					}

					if($("#partido_" + $id).val() == "") {

						alert("Rellena el campo partido");

					} else if($("#fecha_inicio_" + $id).val() == "") {

						alert("Rellena el campo fecha y hora");

					} else if($fin == 1 && $min_gol == -1) {

						alert("Rellena el campo minuto gol");

					} else {

						var parametros = {
							accion : "Update",
							id : $id,
							partido: $("#partido_" + $id).val(),
							fecha_inicio: $("#fecha_inicio_" + $id).val(),
							min_gol: $min_gol,
							finalizado: $fin,
							anulado: $anu
						};

						$.ajax({
							type: 'POST',
							url: "../funciones/sw_partidos.php",
							data: parametros,
							success: function(data){
								console.log(data);
								if (data != 0) {
									location.reload();
									alert("Partido actualizado correctamente");
								} else {
									alert("ERROR: Partido no actualizado");
								}
							},
							error: function (xhr, status, error) {
								console.log("ERROR: " + err.Message);
							}
						});
					}
				}

				function eliminarPartido($id) {

					var parametros = {
						accion : "Delete",
						id : $id
					};

					$.ajax({
						type: 'POST',
						url: "../funciones/sw_partidos.php",
						data: parametros,
						success: function(data){
							console.log(data);
							if (data == 1) {
								location.reload();
								alert("Partido eliminado correctamente");
							} else if (data == -1) {
								alert("ERROR: Partido no eliminado\n\nHay una apuesta en juego para este partido");
							} else {
								alert("ERROR: Partido no eliminado");
							}
						},
						error: function (xhr, status, error) {
							console.log("ERROR: " + err.Message);
						}
					});
				}
			</script>
<?php
		} else {
			// ZONA PUBLICA
			header('Location: ../');
		}
?>
	</body>
</html>