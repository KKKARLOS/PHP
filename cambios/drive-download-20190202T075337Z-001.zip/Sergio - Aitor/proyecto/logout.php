<?php
	session_start();
	unset($_SESSION["usuarioID"]);
	header("Location: ./");
?>