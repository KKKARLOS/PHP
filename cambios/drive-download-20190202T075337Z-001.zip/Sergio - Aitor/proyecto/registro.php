<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Registrate en BeforeGoal</title>
<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
  <div class="menu">
      <a href="."><img src="img/beforegoal_alt.png" width="14px" height="14px"> <b>BEFORE GOAL</b></a>
    </div>
<div id="registro" class="popup">
  <form action="validarEmail.php" method="POST" class="formulario">
  <div style="background-color: #333; color: #f2f2f2; text-align: center; padding: 16px;">
    <b>REGISTRATE</b>
  </div>
  <div style="text-align: center;padding: 16px;">
    <label for="user"><b>Usuario: </b></label>
    <input type="text"  placeholder="Usuario" name="user" class="input" required autofocus>   
    <br><br>
    <label for="password"><b>Contraseña: </b></label>
    <input type="text"  placeholder="Contraseña" name="password" class="input" required>         
      <br><br>
    <label for="email"><b>Email: </b></label>
    <input type="email"  placeholder="Email" name="email" class="input">
  </div>
  <div style="text-align: center;padding: 16px;">
   <input class="button" name="submit" type="submit" value="Registrarse">
  </div>
  </form>
</div>
<script>
          var registro = document.getElementById('registro');
            registro.style.display = "block";

              window.onclick = function(event) {

          if (event.target == registro) {
            location.href ="index.php";
          }
        }
      </script>
</body>
</html>


