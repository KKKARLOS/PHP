<?php
require('../conexion.php');
session_start();

$partido = utf8_decode($_POST['partido']);
$cantidad = utf8_decode($_POST['cantidad']);
$mingol = utf8_decode($_POST['mingol']);

$insert_value = "INSERT INTO apuestas (partido_id, usuario_id, min_gol, apuesta) VALUES (' $partido ', '".$_SESSION["usuarioID"]."', '$mingol', '$cantidad')";
 
$ejecutar = mysqli_query($conn, $insert_value);

if (!$ejecutar){
   die('Error: ' . mysqli_error());
}

$saldo_usu = "SELECT saldo FROM usuarios WHERE usuario_id=".$_SESSION["usuarioID"];
$resultado = mysqli_query($conn, $saldo_usu);

if (mysqli_num_rows($resultado) > 0) {
    while($row = mysqli_fetch_assoc($resultado)) {
        $dineroactual = $row["saldo"];
    }
  }else{
    echo "Error en la obtencion del saldo.";
}

$dinerototal= $dineroactual - $cantidad;

$insert_value = "UPDATE usuarios SET saldo='$dinerototal' WHERE usuario_id=".$_SESSION["usuarioID"];
 
$ejecutar = mysqli_query($conn, $insert_value);

if (!$ejecutar){
   die('Error: ' . mysqli_error());
}else{
	header('Location: ../');
}
  
?>




