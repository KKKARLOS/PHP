<?php
require('../conexion.php');
 
 session_start();

$new_money = utf8_decode($_POST['money']);
$saldo_usu = "SELECT saldo FROM usuarios WHERE usuario_id=".$_SESSION["usuarioID"];
$resultado = mysqli_query($conn, $saldo_usu);

if (mysqli_num_rows($resultado) > 0) {
    while($row = mysqli_fetch_assoc($resultado)) {
        $dineroactual = $row["saldo"];
    }
  }else{
    echo "Error en la obtencion del saldo.";
}

$dinerototal= $dineroactual + $new_money;

$insert_value = "UPDATE usuarios SET saldo='$dinerototal' WHERE usuario_id=".$_SESSION["usuarioID"];
 
$ejecutar = mysqli_query($conn, $insert_value);

if (!$ejecutar){
   die('Error: ' . mysqli_error());
}else{
	header('Location: ../');
}
  
?>



