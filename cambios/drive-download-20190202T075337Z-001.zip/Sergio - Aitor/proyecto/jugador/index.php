<?php
	session_start();
	include("../conexion.php");
	include("../funciones/funciones.php");
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Before Goal</title>
		<link href="../css/estilos.css" rel="stylesheet" type="text/css">
	</head>
	<body>
<?php
		$saldo_usu = "SELECT saldo FROM usuarios WHERE usuario_id = " . $_SESSION['usuarioID'];
		$resultado = mysqli_query($conn, $saldo_usu);

		if(mysqli_num_rows($resultado) > 0) {
			while($row = mysqli_fetch_assoc($resultado)) {
				$saldoUsuario = $row["saldo"];
			}
		} else {
			echo "Error en la carga del saldo.";
		}
?>
		<!-- MENU SUPERIOR -->
		<div class="menu">
			<a href="."><img src="img/beforegoal_alt.png" width="14px" height="14px"> <b>BEFORE GOAL</b></a>
			<span>SALDO <?php echo $saldoUsuario; ?>€</span>
			<a href="#" onclick="document.getElementById('recarga').style.display='block'">RECARGAR SALDO</a>
			<a style="float: right;" href="../logout.php">LOGOUT</a>
		</div>

		<!-- CONTENIDO PÁGINA JUGADOR -->
		<div class="contenido">
			<div style="width: 50%; float: left;">
				<div style="padding: 8px;">
<?php
					$datos_usu = "SELECT a.min_gol, a.apuesta, p.partido FROM apuestas a, partidos p, usuarios u WHERE p.partido_id = a.partido_id AND a.usuario_id = u.usuario_id AND a.usuario_id = " . $_SESSION['usuarioID'];
					$resultado = mysqli_query($conn, $datos_usu);

					if(mysqli_num_rows($resultado) > 0) {

						echo "<table width='100%' cellpadding='8' cellspacing='0' class='tablaPartidos'>";
							echo "<tr>";
								echo "<th colspan='2'>MIS APUESTAS</th>";
							echo "</tr>";
							echo "<tr>";
								echo "<th>PARTIDO</th><th>APUESTA</th>";
							echo "</tr>";

							while($row = mysqli_fetch_assoc($resultado)) {				
								echo "<tr>";
									echo "<td>" . $row["partido"] . "</td><td>Minuto: " . $row["min_gol"] . " x ".$row["apuesta"] . "€</td>";
								echo "</tr>";
							}

						echo "</table>";
					} else {
						echo "No has apostado todavía.";
					}
?>
				</div>
			</div>
			<div style="width: 50%; float: left;">
				<div style="padding: 8px;">

<?php
					echo "<table width='100%' cellpadding='8' cellspacing='0' class='tablaPartidos'>";
						echo "<tr>";
							echo "<th colspan='2'>PARTIDOS</th>";
						echo "</tr>";
						echo "<tr>";
							echo "<th>PARTIDO</th><th>FECHA</th>";
						echo "</tr>";

						$arraypartidosapostados = mostrarpartidosapostados($_SESSION["usuarioID"]);
		
						$datos_part = "SELECT * FROM partidos WHERE finalizado = 0 AND anulado = 0";
						$resultado = mysqli_query($conn, $datos_part);

						if(mysqli_num_rows($resultado) > 0) {
						
							while($row = mysqli_fetch_assoc($resultado)) {
								
								$jugado = false;

								for ($i=0; $i < count($arraypartidosapostados) ; $i++) {
									if($row["partido_id"]==$arraypartidosapostados[$i]) {
										$jugado = true;
									}
								}

								$variable = ($jugado) ? "Disabled" : "";

								echo "<tr>";
									echo "<td><button onclick='abrirPanelApuesta(".$row["partido_id"].")' $variable>".$row["partido"]."</button></td><td>".$row["fecha_inicio"]." </td>";
								echo "</tr>";
							}

						}

					echo "</table>";
?>
				</div>
			</div>
		</div>
		<div id="recarga" class="popup">
			<form action="recarga.php" method="POST" class="formulario animate">
			  <div style="background-color: #333; color: #f2f2f2; text-align: center; padding: 16px;">
			    <h2>Introducir saldo</h2> 
			  </div> 
			  <div style="text-align: center;padding: 16px;">
			    <label for="money">Cantidad (€):</label>
			    <input type="number" name="money" class="form-input" min="5" step="5" required/>
			    </div>
			    <div style="text-align: center;padding: 16px;">  
			   <input class="button" name="submit" type="submit" value="Aceptar" />
			  </div>
		 	</form>
		</div>
		<div id="apostar" class="popup">
			<form action="apostar.php" name="formApostar" method="POST" class="formulario animate">
				   <div style="background-color: #333; color: #f2f2f2; text-align: center; padding: 16px;">
				    <h2>Apuesta</h2> 
				 </div>
				  <div style="text-align: center;padding: 16px;">
				  <input type="hidden" name="partido" id="partido"required/>  
				   <label for="cantidad">Cantidad (€): </label>
				   <br>
				    <?php
				    echo "<input type='number' name='cantidad' class='form-input' min='1'
				     max='".obtenersaldousuario($_SESSION["usuarioID"])."' required/> ";  
				     ?>
				     <br><br>
				    <label for="mingol">Minuto del gol: </label>
				    <br>
				    <input type="number" name="mingol" class="form-input" min="0" max="90" required/>   
				  </div>
				    <div style="text-align: center;padding: 16px;"> 
					<input class="button" name="submit" type="submit" value="Aceptar" /></center>
			 	</div>
  			</form>
		</div>
		<script>
			window.onclick = function(event) {
				var recarga = document.getElementById('recarga');
				var apostar = document.getElementById('apostar');

				if (event.target == recarga || event.target == apostar) {
					recarga.style.display = "none";
					apostar.style.display = "none";
				}
			}

			function abrirPanelApuesta($partido_id) {
				document.formApostar.partido.value = $partido_id;
				document.getElementById('apostar').style.display='block';

			}
		</script>
	</body>
</html>