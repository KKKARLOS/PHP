<?php
	session_start();
	include("conexion.php");

	$email = $_POST["user"];
	$pass = $_POST["pass"];


	$sql = "SELECT usuario_id FROM usuarios WHERE email = '$email' AND password = '$pass'";
	$result = $conn->query($sql);

	$respuesta = 0;

	if ($result->num_rows > 0) {

		while($row = $result->fetch_assoc()) {
			$respuesta = $row["usuario_id"];
		}
	}

	$conn->close();

	if($respuesta != 0) {
		$_SESSION["usuarioID"] = $respuesta;
	}

	header('Location: index.php');
?>