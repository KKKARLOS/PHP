<?php
require('conexion.php');

$new_name = $_POST['user'];
$new_password = $_POST['password'];
$new_email = $_POST['email'];
 
$emailrepe= "SELECT * FROM usuarios WHERE email = '$new_email'";
$resultado = mysqli_query($conn, $emailrepe);

if (mysqli_num_rows($resultado) > 0) {
	echo "<div style='text-align: center;''>Es correo electronico ya existe</div>";
	header( "refresh:3;url=registro.php" );
 
} else {
	$insert_value = "INSERT INTO  usuarios (nombre_usuario , email , password, saldo) VALUES ('$new_name', '$new_email','$new_password', '10')";
 
$retry_value = mysqli_query($conn, $insert_value);
 
if (!$retry_value){
   die('Error: ' . mysqli_error());
}
	
header('Location: index.php');
}
		
?>
