<?php
	$servidor = "localhost";
	$usuario = "root";
	$contrasenna = "";
	$basededatos = "bbdd_beforegoal";

	$conn = new mysqli($servidor, $usuario, $contrasenna, $basededatos);

	if($conn->connect_error) {
		die("Error de conexión: " . $conn->connect_error);
	}
?>