<?php
	session_start();

	include("conexion.php");
	include("funciones/funciones.php");
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>BEFORE GOAL</title>
		<link rel="stylesheet" type="text/css" href="css/estilos.css">
		<script src="jquery.min.js"></script>
	</head>
	<body>
<?php
		if(isset($_SESSION["usuarioID"])) {
			// ZONA PRIVADA
			if(obtenerTipoUsuario($_SESSION["usuarioID"]) == 0) {
				// ZONA ADMIN
				
				header('Location: ./admin/');
			} else {
				// ZONA JUGADOR
				
				header('Location: ./jugador/');
			}
		} else {
			// ZONA PUBLICA
?>
			<!-- MENU SUPERIOR -->
			<div class="menu">
				<a href="."><img src="img/beforegoal_alt.png" width="14px" height="14px"> <b>BEFORE GOAL</b></a>
				<a style="float: right;" href="#" onclick="document.getElementById('login').style.display='block'">LOGIN</a>
			</div>

			<!-- CONTENIDO PÁGINA INVITADO -->
			<div class="contenido" style="text-align: center;">
				<h1 style="font-size: 64px;"><img src="img/beforegoal.png"> BEFOREGOAL</h1>
			</div>

			<!-- FORMULARIO DEL LOGIN -->
			<div id="login" class="popup">
				<form action="login.php" method="POST" class="formulario animate">
					<div style="background-color: #333; color: #f2f2f2; text-align: center; padding: 16px;">
						<img src="img/beforegoal_alt.png">
						<h3>LOGIN</h3>
					</div>
					<div style="text-align: center;padding: 16px;">
						<label for="user"><b>Usuario</b></label>
						<br>
						<input type="text" placeholder="Usuario" id="user" name="user" required autofocus>
						<br><br>
						<label for="pass"><b>Contraseña</b></label>
						<br>
						<input type="password" placeholder="Contraseña" id="pass" name="pass" required>
						<br>
					</div>
					<div style="text-align: center;padding: 16px;">
						<button id="btn_login" name="btn_login" type="submit" class="button">Login</button>
						<br><br>
						<a href="registro.php" class="button">Registrarse</a>
					</div>
				</form>
			</div>

			<script>
				window.onclick = function(event) {
					var login = document.getElementById('login');

					if (event.target == login) {
						login.style.display = "none";
					}
				}
			</script>
<?php
		}
?>
	</body>
</html>